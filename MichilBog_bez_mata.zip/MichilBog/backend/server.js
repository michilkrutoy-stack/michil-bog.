// Minimal Node.js proxy. Keep OPENAI_API_KEY only on the server.
// Install: npm install express
// Run: OPENAI_API_KEY=... node server.js
const express = require("express");
const app = express();
app.use(express.json({ limit: "1mb" }));

app.post("/chat", async (req, res) => {
  try {
    const messages = req.body.messages;
    if (!Array.isArray(messages)) return res.status(400).json({ error: "messages required" });
    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages,
        temperature: 0.8
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) return res.status(upstream.status).json({ error: "AI provider error" });
    res.json({ reply: data.choices?.[0]?.message?.content || "Пустой ответ AI" });
  } catch (e) {
    res.status(500).json({ error: "server_error" });
  }
});

app.listen(process.env.PORT || 3000, () => console.log("Michil bog backend is running"));
