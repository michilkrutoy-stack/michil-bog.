package com.michilbog.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Bg = Color(0xFF10111A)
private val Panel = Color(0xFF1B1D2B)
private val Purple = Color(0xFF9B7BFF)
private val Mint = Color(0xFF8CF0C8)
private val Muted = Color(0xFFAAAABD)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechResult by mutableStateOf("")
    private val audioPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startSpeech() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple, secondary = Mint, background = Bg, surface = Panel
            )) {
                MichilApp(
                    onSpeak = { speak(it) },
                    onListen = { requestSpeech() },
                    speechText = speechResult,
                    clearSpeech = { speechResult = "" }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "michil_reply")
    }

    private fun requestSpeech() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) startSpeech()
        else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startSpeech() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, я слушаю")
        }
        try {
            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onResults(results: Bundle?) {
                    speechResult = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { speechResult = "" }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) { speechResult = "" }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun MichilApp(
    onSpeak: (String) -> Unit,
    onListen: () -> Unit,
    speechText: String,
    clearSpeech: () -> Unit
) {
    var tab by remember { mutableStateOf("Чат") }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Йо! Я Michil bog 🤖 Могу потрещать, пошутить или погонять тебя по IELTS. Чё делаем?", false)
        )
    }
    val scope = rememberCoroutineScope()

    LaunchedEffect(speechText) {
        if (speechText.isNotBlank()) {
            input = speechText
            clearSpeech()
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("MICHIL BOG", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("AI с характером • IELTS без скуки", color = Muted, fontSize = 12.sp)
                }
                Surface(color = Mint.copy(alpha = .15f), shape = RoundedCornerShape(50)) {
                    Text("● ONLINE", color = Mint, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Чат", "IELTS", "Мемы").forEach { item ->
                    val selected = tab == item
                    Surface(
                        color = if (selected) Purple else Panel,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).clickable { tab = item }
                    ) {
                        Text(item, color = Color.White, modifier = Modifier.padding(12.dp), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        when (tab) {
            "Чат" -> {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { msg -> MessageBubble(msg) }
                    if (loading) item { Text("Michil bog печатает…", color = Mint, modifier = Modifier.padding(8.dp)) }
                }
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = onListen) {
                        Icon(Icons.Default.Mic, "Голосовой ввод", tint = Mint)
                    }
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Напиши или нажми 🎤") },
                        shape = RoundedCornerShape(18.dp),
                        maxLines = 3
                    )
                    IconButton(
                        enabled = input.isNotBlank() && !loading,
                        onClick = {
                            val prompt = input.trim()
                            input = ""
                            messages.add(ChatMessage(prompt, true))
                            loading = true
                            scope.launch {
                                val answer = AiClient.reply(messages.dropLast(1))
                                messages.add(ChatMessage(answer, false))
                                loading = false
                            }
                        }
                    ) { Icon(Icons.Default.Send, "Отправить", tint = Purple) }
                }
            }
            "IELTS" -> IeltsScreen { prompt ->
                messages.add(ChatMessage(prompt, true))
                tab = "Чат"
                scope.launch {
                    loading = true
                    val answer = AiClient.reply(messages.dropLast(1), true)
                    messages.add(ChatMessage(answer, false))
                    loading = false
                }
            }
            else -> MemeScreen()
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (message.fromUser) Color(0xFF393052) else Panel,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Text(message.text, color = Color.White, modifier = Modifier.padding(14.dp), lineHeight = 21.sp)
        }
    }
}

@Composable
fun IeltsScreen(onPractice: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("IELTS TRAINING 🇬🇧", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Прокачай английский без занудства. Выбирай тренировку:", color = Muted)
        listOf(
            Triple("🎙 Speaking Part 1", "Разогрев и вопросы о тебе", "Проведи со мной тренировку IELTS Speaking Part 1. Задавай вопросы по одному на английском, после моих ответов объясняй ошибки по-русски и оценивай ориентировочный band."),
            Triple("🔥 Speaking Part 2", "Монолог на 1–2 минуты", "Проведи IELTS Speaking Part 2: дай cue card, подготовь меня, затем оцени мой ответ по критериям IELTS."),
            Triple("✍️ Writing", "Проверка эссе и грамматики", "Помоги подготовиться к IELTS Writing Task 2. Дай тему, затем проверь моё эссе по критериям IELTS и предложи улучшения."),
            Triple("🧠 Vocabulary", "Слова, выражения и примеры", "Учи меня полезной лексике для IELTS: по 5 слов за раз с переводом, примерами и мини-тестом.")
        ).forEach { (title, subtitle, prompt) ->
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { onPractice(prompt) }) {
                Column(Modifier.padding(16.dp)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(subtitle, color = Muted, fontSize = 13.sp)
                }
            }
        }
        Text("Оценки AI ориентировочные и не заменяют официальную оценку IELTS.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun MemeScreen() {
    val jokes = listOf(
        "Я: сегодня выучу 20 слов для IELTS.\nТакже я через 3 минуты: где мемы?",
        "Examiner: Could you elaborate?\nЯ: Конечно. Сейчас объясню…",
        "Мой vocabulary: very good.\nBand 9 vocabulary: exceptionally magnificent.",
        "IELTS Listening: аудио один раз.\nМой мозг: повторите, пожалуйста, жизнь."
    )
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("MEME ZONE 😂", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Немного юмора, чтобы IELTS не вынес мозг.", color = Muted)
        jokes.forEachIndexed { index, joke ->
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Text(joke, color = Color.White, modifier = Modifier.padding(18.dp), fontSize = 16.sp, lineHeight = 23.sp)
            }
        }
    }
}

object AiClient {
    // Укажите адрес собственного HTTPS backend. Не храните секретный API-ключ в приложении.
    private const val BACKEND_URL = "https://YOUR_BACKEND_DOMAIN/chat"
    private val client = OkHttpClient()
    private val mediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun reply(history: List<ChatMessage>, ielts: Boolean = false): String =
        withContext(Dispatchers.IO) {
            try {
                val system = if (ielts) {
                    "Ты Michil bog — дружелюбный IELTS-тренер. Общайся по-русски, примеры и задания давай на английском. Используй только вежливую лексику: никогда не используй мат, ругань, оскорбления или грубые выражения, даже если пользователь сам их использует. Если пользователь просит ругаться, вежливо откажись и продолжай без мата. Оценивай ориентировочно по критериям IELTS, не выдавай оценку за официальную."
                } else {
                    "Ты Michil bog — русскоязычный AI-друг. Общайся естественно, дружелюбно и с лёгким юмором. Всегда используй только вежливую лексику: никогда не используй мат, ругань, оскорбления или грубые выражения, даже если пользователь сам их использует. Если пользователь просит ругаться, вежливо откажись и продолжай без мата. Помогай с IELTS, английским и повседневными вопросами."
                }
                val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
                history.takeLast(20).forEach {
                    msgs.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text))
                }
                val body = JSONObject().put("messages", msgs).toString().toRequestBody(mediaType)
                val request = Request.Builder().url(BACKEND_URL).post(body).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext "Сервер ответил ошибкой ${response.code}. Проверь подключение AI."
                    val json = JSONObject(response.body?.string().orEmpty())
                    json.optString("reply").ifBlank { "Что-то я завис 😅 Попробуй ещё раз." }
                }
            } catch (_: Exception) {
                "Я пока в демо-режиме 😅 Подключи backend в AiClient.kt, чтобы я смог отвечать как настоящий AI."
            }
        }
}
